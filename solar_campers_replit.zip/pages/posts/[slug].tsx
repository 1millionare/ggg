import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import { remark } from 'remark'
import html from 'remark-html'

export async function getStaticPaths() {
  const files = fs.readdirSync(path.join('posts'))
  const paths = files.map(filename => ({
    params: { slug: filename.replace('.md', '') }
  }))
  return { paths, fallback: false }
}

export async function getStaticProps({ params: { slug } }) {
  const markdownWithMeta = fs.readFileSync(path.join('posts', slug + '.md'), 'utf-8')
  const { data: frontmatter, content } = matter(markdownWithMeta)
  const processedContent = await remark().use(html).process(
    content.replaceAll('(#[)]', '(https://amzn.to/YOUR-AFFILIATE-ID)')
  )
  const contentHtml = processedContent.toString()

  return {
    props: { frontmatter, contentHtml }
  }
}

export default function PostPage({ frontmatter, contentHtml }) {
  return (
    <div className="p-8 max-w-3xl mx-auto font-sans">
      <h1 className="text-3xl font-bold mb-4">{frontmatter.title}</h1>
      <div dangerouslySetInnerHTML={{ __html: contentHtml }} className="prose" />
    </div>
  )
}
