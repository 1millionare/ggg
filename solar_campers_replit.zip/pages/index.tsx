import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import Link from 'next/link'
import { useEffect, useState } from 'react'

export async function getStaticProps() {
  const files = fs.readdirSync(path.join('posts'))

  const posts = files.map(filename => {
    const markdownWithMeta = fs.readFileSync(path.join('posts', filename), 'utf-8')
    const { data: frontmatter } = matter(markdownWithMeta)

    return {
      slug: filename.replace('.md', ''),
      frontmatter
    }
  })

  return {
    props: { posts }
  }
}

export default function Home({ posts }) {
  const [showPopup, setShowPopup] = useState(false)
  useEffect(() => {
    const timer = setTimeout(() => setShowPopup(true), 8000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="p-8 max-w-3xl mx-auto font-sans">
      <h1 className="text-4xl font-bold mb-6">Solar Campers Blog</h1>
      {posts.map(post => (
        <div key={post.slug} className="mb-6">
          <Link href={`/posts/${post.slug}`}>
            <a className="text-2xl text-blue-600 font-semibold">{post.frontmatter.title}</a>
          </Link>
          <p className="text-gray-700">{post.frontmatter.excerpt}</p>
        </div>
      ))}

      {showPopup && (
        <div className="fixed bottom-4 right-4 bg-white border p-4 rounded-xl shadow-xl z-50">
          <h2 className="text-lg font-semibold mb-2">Join our mailing list</h2>
          <form onSubmit={e => e.preventDefault()}>
            <input type="email" placeholder="you@example.com" className="border p-2 rounded w-full mb-2" />
            <button className="bg-blue-600 text-white px-4 py-2 rounded">Subscribe</button>
          </form>
        </div>
      )}
    </div>
  )
}
