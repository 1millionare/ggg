---
title: "Example Post for Solar Blog"
excerpt: "An example to show how affiliate injection and rendering works."
---

Here's a great solar product you might like:

[Check Price on Amazon](#)

Stay powered up!
